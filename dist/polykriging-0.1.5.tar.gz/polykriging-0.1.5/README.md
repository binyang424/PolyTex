An implementation of Kriging.



This kriging library for (parametric) curve and surface reconstruction and interpolation is developed
in Python 3 using 64-bit deployment.