import os
import json

cwd = os.getcwd()
print("Current working directory: {0}".format(cwd))
os.chdir(cwd)

for file in ["PyFoamState.CurrentTime", "PyFoamState.LogDir", 
             "PyFoamState.TheState", "PyFoamServer.info", "PyFoamRunner.decomposePar.logfile"]:
    try:
        # delete file
        os.remove(file)
        print("Deleted file: {0}".format(file))
    except OSError:
        print("File not found: {0}".format(file))
        pass
    
if os.path.isfile("PyFoamRecords") and os.stat("PyFoamRecords").st_size > 0:
    with open("PyFoamRecords", "r") as f:
        pyFoamRecords = json.load(f)
else:
    pyFoamRecords = {"PyFoamState.StartedAt": "",
                     "PyFoamState.LastOutputSeen": "",
                     "PyFoamHistory": []
                     }

for file in ["PyFoamState.StartedAt", "PyFoamState.LastOutputSeen",
             "PyFoamHistory"]:
    try:
        # read file
        with open(file, "r") as f:
            if file in ["PyFoamState.StartedAt", "PyFoamState.LastOutputSeen"]:
                pyFoamRecords[file] = f.read()
            else:
                lines = [line.replace(" by by in ubuntu :Application", "") 
                         for line in f.read().splitlines()]
                pyFoamRecords[file] += lines
        # delete file
        os.remove(file)
        print("Deleted file: {0}".format(file))
    except OSError:
        print("File not found: {0}".format(file))
        pass
    
# save records to file pretty printed
with open("PyFoamRecords", "w") as f:
    json.dump(pyFoamRecords, f, indent=4, sort_keys=False)
    print("Saved file: PyFoamRecords")
